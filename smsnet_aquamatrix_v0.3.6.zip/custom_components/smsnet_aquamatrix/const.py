from __future__ import annotations
DOMAIN = "smsnet_aquamatrix"
DEFAULT_BASE_URL = "https://www.aquamatrix.pt"
CONF_TENANT = "tenant"
CONF_USERNAME = "username"
CONF_PASSWORD = "password"
PLATFORMS = ["sensor"]
